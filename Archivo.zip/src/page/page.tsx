import React from "react";
import Link from "next/link";

function LandingPage() {
  return (
    <div>
      <h1>Emprendeart</h1>

      <Link href="/home">Inicio</Link>
    </div>
  );
}

export default LandingPage;
