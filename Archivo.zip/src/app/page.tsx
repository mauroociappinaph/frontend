import React from "react";

import LandingPage from "@/page/page";

function HomePage() {
  return <LandingPage />;
}

export default HomePage;
