import React from "react";

function ProductNewPage() {
  return (
    <div>
      <h1>Product New Page</h1>
    </div>
  );
}

export default ProductNewPage;
